package play.mickedplay.gameapi.utilities.game;

/**
 * Created by mickedplay on 17.08.2016 at 20:42 CEST.
 * You are not allowed to remove this comment.
 */
public enum TimeType {
    HOURS_MINUTES, MINUTES_SECONDS, SECONDS_MILLISECONDS
}