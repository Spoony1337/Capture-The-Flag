package play.mickedplay.gameapi.utilities.game;

/**
 * Created by mickedplay on 17.08.2016 at 20:42 CEST.
 * You are not allowed to remove this comment.
 */
public enum Cardinal {
    NORTH, EAST, SOUTH, WEST, UP, DOWN
}
