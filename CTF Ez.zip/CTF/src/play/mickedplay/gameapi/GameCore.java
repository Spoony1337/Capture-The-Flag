package play.mickedplay.gameapi;

public class GameCore {
    public static final String DEFAULT_TEMPLATE_FILE = "Ignore this..";
}